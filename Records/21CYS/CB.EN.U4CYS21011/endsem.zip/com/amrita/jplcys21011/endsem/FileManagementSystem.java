package com.amrita.jplcys21011.endsem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

/**
 * Represents a basic file.
 */
class File {
    private String fileName;
    private int fileSize;

    public File(String fileName, int fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    /**
     * Returns the file name.
     *
     * @return The file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Returns the file size.
     *
     * @return The file size
     */
    public int getFileSize() {
        return fileSize;
    }

    /**
     * Displays the file details.
     */
    public void displayFileDetails() {
        System.out.println("File Name: " + fileName);
        System.out.println("File Size: " + fileSize);
    }
}

/**
 * Represents a document file, which is a subclass of File.
 */
class Document extends File {
    private String documentType;

    public Document(String fileName, int fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    /**
     * Returns the document type.
     *
     * @return The document type
     */
    public String getDocumentType() {
        return documentType;
    }

    /**
     * Displays the document file details.
     */
    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }
}

/**
 * Represents an image file, which is a subclass of File.
 */
class Image extends File {
    private String resolution;

    public Image(String fileName, int fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    /**
     * Returns the image resolution.
     *
     * @return The image resolution
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Displays the image file details.
     */
    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Resolution: " + resolution);
    }
}

/**
 * Represents a video file, which is a subclass of File.
 */
class Video extends File {
    private String duration;

    public Video(String fileName, int fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    /**
     * Returns the video duration.
     *
     * @return The video duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Displays the video file details.
     */
    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Duration: " + duration);
    }
}

/**
 * Represents the file management operations.
 */
interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void displayAllFiles();

    void saveToFile(String fileName);

    void loadFromFile(String fileName);

    File[] getFiles();
}

/**
 * Implements the file management operations.
 */
class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    @Override
    public void displayAllFiles() {
        for (File file : files) {
            file.displayFileDetails();
            System.out.println();
        }
    }

    @Override
    public void saveToFile(String fileName) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            outputStream.writeObject(files);
            System.out.println("File details saved to " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void loadFromFile(String fileName) {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            files = (ArrayList<File>) inputStream.readObject();
            System.out.println("File details loaded from " + fileName);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public File[] getFiles() {
        return files.toArray(new File[0]);
    }
}

/**
 * Represents the user interface for the file management system.
 */
class FileManagementSystemUI extends JFrame implements ActionListener {
    private FileManager fileManager;
    private DefaultTableModel tableModel;

    private JTextField fileNameField, fileSizeField, fileTypeField, resolutionField, durationField;
    private JButton addDocumentButton, addImageButton, addVideoButton, deleteButton, displayButton,
            saveButton, loadButton;
    private JTable fileTable;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();

        setTitle("File Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        createFileInputPanel();
        createFileTable();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Creates the file input panel.
    private void createFileInputPanel() {
        JPanel fileInputPanel = new JPanel();
        fileInputPanel.setLayout(new FlowLayout());

        JLabel fileNameLabel = new JLabel("File Name:");
        fileNameField = new JTextField(10);

        JLabel fileSizeLabel = new JLabel("File Size:");
        fileSizeField = new JTextField(5);

        JLabel fileTypeLabel = new JLabel("Document Type:");
        fileTypeField = new JTextField(10);

        addDocumentButton = new JButton("Add Document");
        addDocumentButton.addActionListener(this);

        addImageButton = new JButton("Add Image");
        addImageButton.addActionListener(this);

        addVideoButton = new JButton("Add Video");
        addVideoButton.addActionListener(this);

        fileInputPanel.add(fileNameLabel);
        fileInputPanel.add(fileNameField);
        fileInputPanel.add(fileSizeLabel);
        fileInputPanel.add(fileSizeField);
        fileInputPanel.add(fileTypeLabel);
        fileInputPanel.add(fileTypeField);
        fileInputPanel.add(addDocumentButton);
        fileInputPanel.add(addImageButton);
        fileInputPanel.add(addVideoButton);

        add(fileInputPanel, BorderLayout.NORTH);
    }

    // Creates the file table.
    private void createFileTable() {
        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("Type");

        fileTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(fileTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(this);

        displayButton = new JButton("Display All");
        displayButton.addActionListener(this);

        saveButton = new JButton("Save to File");
        saveButton.addActionListener(this);

        buttonPanel.add(deleteButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(saveButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Handles button actions.
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addDocumentButton) {
            String fileName = fileNameField.getText();
            int fileSize = Integer.parseInt(fileSizeField.getText());
            String documentType = fileTypeField.getText();

            Document document = new Document(fileName, fileSize, documentType);
            fileManager.addFile(document);
            addFileToTable(document);
        } else if (e.getSource() == addImageButton) {
            String fileName = fileNameField.getText();
            int fileSize = Integer.parseInt(fileSizeField.getText());
            String resolution = fileTypeField.getText();

            Image image = new Image(fileName, fileSize, resolution);
            fileManager.addFile(image);
            addFileToTable(image);
        } else if (e.getSource() == addVideoButton) {
            String fileName = fileNameField.getText();
            int fileSize = Integer.parseInt(fileSizeField.getText());
            String duration = fileTypeField.getText();

            Video video = new Video(fileName, fileSize, duration);
            fileManager.addFile(video);
            addFileToTable(video);
        } else if (e.getSource() == deleteButton) {
            int selectedRow = fileTable.getSelectedRow();
            if (selectedRow != -1) {
                String fileName = tableModel.getValueAt(selectedRow, 0).toString();
                fileManager.deleteFile(fileName);
                tableModel.removeRow(selectedRow);
            }
        } else if (e.getSource() == displayButton) {
            fileManager.displayAllFiles();
        } else if (e.getSource() == saveButton) {
            String fileName = JOptionPane.showInputDialog("Enter the file name:");
            fileManager.saveToFile(fileName);
        }
    }

    // Adds a file to the file table.
    private void addFileToTable(File file) {
        Object[] rowData = new Object[3];
        rowData[0] = file.getFileName();
        rowData[1] = file.getFileSize();

        if (file instanceof Document) {
            rowData[2] = "Document";
        } else if (file instanceof Image) {
            rowData[2] = "Image";
        } else if (file instanceof Video) {
            rowData[2] = "Video";
        }

        tableModel.addRow(rowData);
    }
}

/**
 * The main class to run the file management system.
 */
public class FileManagementSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}
